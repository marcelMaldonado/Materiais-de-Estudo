(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-8f4c699e-d670-4f69-a33b-cc3008d5c666 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-8ab43323-7e5e-4da5-86c4-7b95211e53d7 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-87dd32c8-eb76-471d-a47c-bd93be6aaee1 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-47c8cb79-8a0c-4397-b39a-567250415a4a .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-5642d3b4-5b2d-4137-af33-e1fb41660b7d .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-1a754361-0a48-4533-849a-e3d6d736e696 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b61c6b03-435c-4716-9c17-1fd9c94af38e .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-be35a1fb-041b-4048-917e-1b3d9b42a39a .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-1053e7ae-25b9-4cc6-9af1-e6712f7e201e .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);