jQuery("#simulation")
  .on("pageload", ".s-8ab43323-7e5e-4da5-86c4-7b95211e53d7 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-8ab43323-7e5e-4da5-86c4-7b95211e53d7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 2000
                  }
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5642d3b4-5b2d-4137-af33-e1fb41660b7d"
                  }
                }
              ]
            }
          ]
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });