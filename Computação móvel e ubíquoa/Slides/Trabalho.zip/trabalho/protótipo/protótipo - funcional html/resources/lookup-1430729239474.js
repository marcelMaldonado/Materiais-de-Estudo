(function(window, undefined) {
  var dictionary = {
    "8f4c699e-d670-4f69-a33b-cc3008d5c666": "Main Screen 2",
    "8ab43323-7e5e-4da5-86c4-7b95211e53d7": "Splash Screen",
    "87dd32c8-eb76-471d-a47c-bd93be6aaee1": "Chat Screen",
    "47c8cb79-8a0c-4397-b39a-567250415a4a": "Main Screen Search",
    "5642d3b4-5b2d-4137-af33-e1fb41660b7d": "Main Screen",
    "1a754361-0a48-4533-849a-e3d6d736e696": "Input Route Screen",
    "b61c6b03-435c-4716-9c17-1fd9c94af38e": "Login Screen",
    "be35a1fb-041b-4048-917e-1b3d9b42a39a": "Route",
    "1053e7ae-25b9-4cc6-9af1-e6712f7e201e": "Routes",
    "e59d1dbf-fdf1-40b8-9165-8147c6635dc8": "NoTemplate",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Basic Template"
  };

  var uriRE = /^(\/#)?(screens|templates|masters)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);