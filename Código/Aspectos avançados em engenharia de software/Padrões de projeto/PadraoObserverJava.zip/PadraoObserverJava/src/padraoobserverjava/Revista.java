/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padraoobserverjava;

import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author Marco
 */
public class Revista extends Observable {

    private int edicao;

    public void setNovaEdicao(int novaEdicao) {
        this.edicao = novaEdicao;
        setChanged();
        notifyObservers();
    }

    public int getEdicao() {
        return this.edicao;
    }


}
