/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraostate;

/**
 *
 * @author Marco
 */
public interface AlunoEstado {
    
    public String getEstado();
    
    public String matricular();
    
    public String formar();
    
}
