/*
 * DatabaseLocator.java
 *
 * Created on 18 de Novembro de 2006, 11:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseLocator {
  private static DatabaseLocator instance = new DatabaseLocator();
  public static DatabaseLocator getInstance() {
    return instance;
  }
  private DatabaseLocator() {}
  
  public Connection getConnection() throws SQLException, 
          ClassNotFoundException
  {
      Class.forName("com.mysql.jdbc.Driver");
      Connection conn = 
        DriverManager.getConnection("jdbc:mysql://localhost/designpattern", "root", "admin");
      return conn;
  }
}










