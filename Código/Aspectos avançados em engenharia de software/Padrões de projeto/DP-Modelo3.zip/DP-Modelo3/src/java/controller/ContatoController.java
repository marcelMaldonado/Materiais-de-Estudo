/*
 * ContatoController.java
 *
 * Created on 18 de Novembro de 2006, 12:13
 */

package controller;

import java.io.*;
import java.net.*;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.http.*;
import model.Contato;
import persistence.ContatoDAO;

public class ContatoController extends HttpServlet {
  
  /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
   * @param request servlet request
   * @param response servlet response
   */
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException, ClassNotFoundException {
    String nome = request.getParameter("textNome");
    String email = request.getParameter("textEmail");
    if(nome.equals("") || email.equals("")) {
      response.sendRedirect("index.jsp");
    } else {
      try {
        Contato contato = new Contato(nome, email);
        ContatoDAO.getInstance().save(contato);
        response.sendRedirect("contatoSucesso.jsp");
        
      } catch (SQLException ex) {
        response.sendRedirect("contatoErro.jsp");
        ex.printStackTrace();
      }
    }
  }
  
  // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
  /** Handles the HTTP <code>GET</code> method.
   * @param request servlet request
   * @param response servlet response
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ServletException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
  }
  
  /** Handles the HTTP <code>POST</code> method.
   * @param request servlet request
   * @param response servlet response
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ServletException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
  }
  
  /** Returns a short description of the servlet.
   */
  public String getServletInfo() {
    return "Short description";
  }
  // </editor-fold>
}
