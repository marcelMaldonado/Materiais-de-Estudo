/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraochainofresponsability;

import junit.framework.TestCase;

/**
 *
 * @author Marco
 */
public class DocumentoTest extends TestCase {
    
    private FuncionarioReitor reitor;
    private FuncionarioDiretor diretor;
    private FuncionarioCoordenador coordenador;
    private FuncionarioSecretaria secretaria;
    
    public DocumentoTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        reitor = new FuncionarioReitor(null);
        diretor = new FuncionarioDiretor(reitor);
        coordenador = new FuncionarioCoordenador(diretor);
        secretaria = new FuncionarioSecretaria(coordenador);
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
    public void testDocumentoHistorico() { 
        assertEquals("Secretaria", 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoHistorico())));
    }

    public void testDocumentoMatricula() { 
        assertEquals("Coordenador", 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoMatricula())));
    }

    public void testDocumentoCertificado() { 
        assertEquals("Diretor", 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoCertificado())));
    }
    
    public void testDocumentoDiploma() { 
        assertEquals("Reitor", 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoDiploma())));
    }
    
    public void testDocumentoBoleto() { 
        assertEquals("Sem assinatura", 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoBoleto())));
    }


}