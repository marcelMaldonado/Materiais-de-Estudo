/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraochainofresponsability;

import java.util.ArrayList;

/**
 *
 * @author Marco
 */
public class RolDocumentos {
    private static RolDocumentos rolDocumentos = new RolDocumentos();
    private TipoDocumentoHistorico tipoDocumentoHistorico;
    private TipoDocumentoMatricula tipoDocumentoMatricula;
    private TipoDocumentoCertificado tipoDocumentoCertificado;
    private TipoDocumentoDiploma tipoDocumentoDiploma;
    private TipoDocumentoBoleto tipoDocumentoBoleto;
    
    private RolDocumentos() 
    {
        tipoDocumentoHistorico = new TipoDocumentoHistorico();
        tipoDocumentoMatricula = new TipoDocumentoMatricula();
        tipoDocumentoCertificado = new TipoDocumentoCertificado();
        tipoDocumentoDiploma = new TipoDocumentoDiploma();
    };
    
    public static RolDocumentos getInstance() {
        return rolDocumentos;
    }
    
    public TipoDocumentoHistorico getTipoDocumentoHistorico() {
        return tipoDocumentoHistorico; 
    }
    
    public TipoDocumentoMatricula getTipoDocumentoMatricula() {
        return tipoDocumentoMatricula; 
    }
    
    public TipoDocumentoCertificado getTipoDocumentoCertificado() {
        return tipoDocumentoCertificado; 
    }

    public TipoDocumentoDiploma getTipoDocumentoDiploma() {
        return tipoDocumentoDiploma; 
    }
    
    public TipoDocumentoBoleto getTipoDocumentoBoleto() {
        return tipoDocumentoBoleto; 
    }
}