/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraochainofresponsability;

/**
 *
 * @author Marco
 */
public class PadraoChainOfResponsability {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FuncionarioReitor reitor = new FuncionarioReitor(null);
        FuncionarioDiretor diretor = new FuncionarioDiretor(reitor);
        FuncionarioCoordenador coordenador = new FuncionarioCoordenador(diretor);
        FuncionarioSecretaria secretaria = new FuncionarioSecretaria(coordenador);

        System.out.println( 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoHistorico())));
        System.out.println( 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoMatricula())));
        System.out.println( 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoCertificado())));
        System.out.println( 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoDiploma())));
        System.out.println( 
          secretaria.assinarDocumento(
            new Documento(RolDocumentos.getInstance().getTipoDocumentoBoleto())));
    }
}
