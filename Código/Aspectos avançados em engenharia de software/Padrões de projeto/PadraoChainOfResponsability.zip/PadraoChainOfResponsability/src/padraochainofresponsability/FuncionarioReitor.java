/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraochainofresponsability;

/**
 *
 * @author Marco
 */
public class FuncionarioReitor extends Funcionario {

    public FuncionarioReitor(Funcionario superior) {
        listaDocumentos.add(RolDocumentos.getInstance().getTipoDocumentoDiploma());
        setFuncionarioSuperior(superior);
    }
    
    public String getDescricaoCargo() {
        return "Reitor";
    }

}
