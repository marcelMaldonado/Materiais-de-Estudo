/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraochainofresponsability;

/**
 *
 * @author Marco
 */
public class FuncionarioDiretor extends Funcionario {

    public FuncionarioDiretor(Funcionario superior) {
        listaDocumentos.add(RolDocumentos.getInstance().getTipoDocumentoCertificado());
        setFuncionarioSuperior(superior);
    }
    
    public String getDescricaoCargo() {
        return "Diretor";
    }

}
