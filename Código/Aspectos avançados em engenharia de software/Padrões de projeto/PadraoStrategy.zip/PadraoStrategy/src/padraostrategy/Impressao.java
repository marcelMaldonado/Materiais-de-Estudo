/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraostrategy;

/**
 *
 * @author maraujo
 */
public interface Impressao {
    public String imprimir();
}
