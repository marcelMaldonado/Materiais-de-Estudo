/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraostrategy;

/**
 *
 * @author maraujo
 */
public class ImpressaoImpressora implements Impressao {
    
    public String imprimir() {
        return "Impressora>>"; 
    }
}
