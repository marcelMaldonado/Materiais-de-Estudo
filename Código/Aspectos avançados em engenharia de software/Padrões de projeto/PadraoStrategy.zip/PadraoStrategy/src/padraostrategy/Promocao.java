/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraostrategy;

/**
 *
 * @author Marco
 */
public interface Promocao {
    public int obterDesconto();
    public String obterPromocao();
    
}
