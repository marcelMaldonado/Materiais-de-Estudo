/*
 * Action.java
 *
 * Created on 18 de Novembro de 2006, 12:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Action {
  public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException;
}
