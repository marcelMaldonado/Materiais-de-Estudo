/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraomemento;

/**
 *
 * @author Marco
 */
public class AlunoMemento {
    private AlunoEstado estado;
    
    public AlunoMemento(AlunoEstado estadoSalvar) {
        estado = estadoSalvar;
    }

    public AlunoEstado getEstadoSalvo() {
        return estado;
    }    
}
