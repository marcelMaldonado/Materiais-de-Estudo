/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraomemento;

/**
 *
 * @author Marco
 */
public class AlunoEstadoFormado implements AlunoEstado {
    
    public String getEstado() {
        return "Formado";
    }
    
    public String matricular() {
        return "Matrícula não pode ser realizada";
    }
}
