/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraomemento;

import java.util.ArrayList;

/**
 *
 * @author Marco
 */
public class PadraoMemento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<AlunoMemento> estadosSalvos = new ArrayList();
        // TODO code application logic here
        
        Aluno aluno = new Aluno();
        
        aluno.setNome("Marco");
        
        aluno.setEstado(new AlunoEstadoTrancado());
        System.out.println ("Aluno " + aluno.getNome() + " está no estado " + aluno.getNomeEstado() + " - " + aluno.matricular());
        
        estadosSalvos.add(aluno.saveToMemento());
        
        aluno.setEstado(new AlunoEstadoAtivo());
        System.out.println ("Aluno " + aluno.getNome() + " está no estado " + aluno.getNomeEstado() + " - " + aluno.matricular());
        
        aluno.restoreFromMemento(estadosSalvos.get(0));
        System.out.println ("Aluno " + aluno.getNome() + " está no estado " + aluno.getNomeEstado() + " - " + aluno.matricular());
       
        
    }
}
