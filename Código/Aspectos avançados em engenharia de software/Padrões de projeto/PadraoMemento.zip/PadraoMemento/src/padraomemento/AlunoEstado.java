/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraomemento;

/**
 *
 * @author Marco
 */
public interface AlunoEstado {
    
    public String getEstado();
    
    public String matricular();
    
}
