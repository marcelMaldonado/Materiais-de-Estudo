/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package padraomemento;

/**
 *
 * @author Marco
 */
public class Aluno {
    
    private String nome;
    private AlunoEstado estado;

    public Aluno() {
        this.estado = new AlunoEstadoAtivo();
    }
    
    public void setEstado(AlunoEstado estado) {
        this.estado = estado;
    }
    
    public String matricular() {
        return estado.matricular();
    }
    
    public String getNomeEstado() {
        return estado.getEstado();
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the estado
     */
    public AlunoEstado getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public AlunoMemento saveToMemento() {
        return new AlunoMemento(estado);
    }

    public void restoreFromMemento(AlunoMemento memento) {
        estado = memento.getEstadoSalvo();
    }
    
}
