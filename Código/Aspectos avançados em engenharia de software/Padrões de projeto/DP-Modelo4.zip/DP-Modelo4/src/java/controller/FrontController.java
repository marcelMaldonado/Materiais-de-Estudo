/*
 * LivroController.java
 *
 * Created on 18 de Novembro de 2006, 12:13
 */

package controller;

import action.GravarContatoAction;
import action.LerContatoAction;
import java.io.*;
import java.net.*;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.http.*;

public class FrontController extends HttpServlet {

  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
    String action = request.getParameter("action");
    Action actionObject=null;
    if(action==null || action.equals(""))
      response.sendRedirect("index.jsp");
    if(action.equals("GravarContato")) {
      actionObject = new GravarContatoAction();
    } else if(action.equals("LerContato")) {
      //acao de ler contato
       actionObject = new LerContatoAction();
    } else if(action.equals("ApagarContato")) {
      //acao de apagar contato
    }
    if(actionObject!=null) 
      actionObject.execute(request, response);
    
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
    processRequest(request, response);
  }
  

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
    processRequest(request, response);
  }
  
  /** Returns a short description of the servlet.
   */
  public String getServletInfo() {
    return "Short description";
  }
  // </editor-fold>
}
