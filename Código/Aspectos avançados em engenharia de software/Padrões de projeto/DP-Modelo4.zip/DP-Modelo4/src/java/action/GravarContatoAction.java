/*
 * GravarContatoAction.java
 *
 * Created on 18 de Novembro de 2006, 12:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package action;

import controller.Action;
import java.io.IOException;
import javax.servlet.http.*;
import java.sql.*;
import model.Contato;
import persistence.ContatoDAO;

public class GravarContatoAction implements Action {
    
    public GravarContatoAction() {
                 
    }
    
    public void execute(HttpServletRequest request,
            HttpServletResponse response ) throws IOException {
        String nome = request.getParameter("textNome");
        String email = request.getParameter("textEmail");
        if(nome.equals("") || email.equals("")) {
            response.sendRedirect("index.jsp");
        } else {
            Contato contato = new Contato(nome, email);
            try {
                ContatoDAO.getInstance().save(contato);
                response.sendRedirect("contatoSucesso.jsp");
            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (SQLException ex) {
                response.sendRedirect("contatoErro.jsp");
                ex.printStackTrace();
            }
        }
    }
}
