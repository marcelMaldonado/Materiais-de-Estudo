/*
 * ApagarContatoAction.java
 *
 * Created on 18 de Novembro de 2006, 12:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package action;

import controller.Action;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ApagarContatoAction implements Action{


  public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
  }
  
}
