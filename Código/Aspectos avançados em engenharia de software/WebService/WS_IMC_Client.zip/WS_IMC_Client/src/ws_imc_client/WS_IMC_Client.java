/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ws_imc_client;

/**
 *
 * @author Marco
 */
public class WS_IMC_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    System.out.println(calcIMC("Masculino",1.83f,120));
    }

    private static String calcIMC(java.lang.String sexo, float altura, float peso) {
        webservice.IMCWebService_Service service = new webservice.IMCWebService_Service();
        webservice.IMCWebService port = service.getIMCWebServicePort();
        return port.calcIMC(sexo, altura, peso);
    }

    
}
