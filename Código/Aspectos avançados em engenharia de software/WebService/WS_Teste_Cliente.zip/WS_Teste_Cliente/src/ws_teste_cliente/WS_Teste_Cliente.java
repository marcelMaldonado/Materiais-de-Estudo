/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ws_teste_cliente;

import model.Resposta;

/**
 *
 * @author Marco
 */
public class WS_Teste_Cliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Resposta resposta = operacao(1,"abc"); 
        System.out.println(resposta.getCodigo() + "-" + resposta.getDescricao());
    }

    private static Resposta operacao(int parametro1, java.lang.String parametro2) {
        model.WebServiceTeste_Service service = new model.WebServiceTeste_Service();
        model.WebServiceTeste port = service.getWebServiceTestePort();
        return port.operacao(parametro1, parametro2);
    }
    
}
