/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Marco
 */
@WebService(serviceName = "WebServiceTeste")
@Stateless()
public class WebServiceTeste {

    /**
     * Operação de Web service
     */
    @WebMethod(operationName = "operacao")
    public Resposta operacao(@WebParam(name = "parametro1") int parametro1, @WebParam(name = "parametro2") String parametro2) {
        return new Resposta(parametro1, parametro2);
    }



}
