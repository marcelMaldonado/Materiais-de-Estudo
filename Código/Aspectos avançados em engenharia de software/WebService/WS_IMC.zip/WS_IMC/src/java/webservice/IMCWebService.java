/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservice;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Marco
 */
@WebService(serviceName = "IMCWebService")
@Stateless()
public class IMCWebService {

    /**
     * Operação de Web service
     */
    @WebMethod(operationName = "calcIMC")
    public String calcIMC(@WebParam(name = "sexo") String sexo, @WebParam(name = "altura") float altura, @WebParam(name = "peso") float peso) {
        String condicao;

        double calculo = peso / (altura * altura);

        if (sexo.equals("Masculino")) {
            if (calculo < 20.7) {
                condicao = "Abaixo do peso";
            } else if (calculo <= 26.4) {
                condicao = "No peso normal";
            } else if (calculo <= 27.8) {
                condicao = "Marginalmente acima do peso";
            } else if (calculo <= 31.1) {
                condicao = "Acima do peso ideal";
            } else {
                condicao = "Obeso";
            }
        } else {
            if (calculo < 19.1) {
                condicao = "Abaixo do peso";
            } else if (calculo <= 25.8) {
                condicao = "No peso normal";
            } else if (calculo <= 27.3) {
                condicao = "Marginalmente acima do peso";
            } else if (calculo <= 32.3) {
                condicao = "Acima do peso ideal";
            } else {
                condicao = "Obeso";
            }
        }

        return condicao;

    }

}
